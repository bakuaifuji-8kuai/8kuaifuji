import{ag as o,ah as n}from"./index-ZQtPgVKA.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
